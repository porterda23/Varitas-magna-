import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function VeritasMagnaSimulator() {
  const [citizenshipPath, setCitizenshipPath] = useState("");
  const [virtue, setVirtue] = useState("");
  const [result, setResult] = useState("");

  const handleSimulate = () => {
    if (!citizenshipPath || !virtue) {
      setResult("Please select a path and virtue.");
      return;
    }

    const outcomes = {
      "military+loyalty": "You earn full citizenship with honor and are appointed as a local militia leader.",
      "infrastructure+discipline": "You rise through civic ranks and manage city planning for a generation.",
      "education+excellence": "You become a national instructor and shape young minds through logic and rhetoric.",
      "health+service": "You are revered as a healer and community elder, guiding families in times of crisis."
    };

    const key = `${citizenshipPath}+${virtue}`;
    setResult(outcomes[key] || "Your service is valued, but your influence remains modest.");
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">Veritas Magna: Civic Simulator</h1>
      <Card>
        <CardContent className="space-y-4">
          <div>
            <label className="font-semibold">Select your path to citizenship:</label>
            <select onChange={e => setCitizenshipPath(e.target.value)} className="w-full border p-2 rounded">
              <option value="">-- Choose --</option>
              <option value="military">Military Defense</option>
              <option value="infrastructure">Civic Infrastructure</option>
              <option value="education">Public Education</option>
              <option value="health">Health and Emergency Response</option>
            </select>
          </div>

          <div>
            <label className="font-semibold">Select your defining virtue:</label>
            <select onChange={e => setVirtue(e.target.value)} className="w-full border p-2 rounded">
              <option value="">-- Choose --</option>
              <option value="loyalty">Loyalty</option>
              <option value="discipline">Discipline</option>
              <option value="excellence">Excellence</option>
              <option value="service">Service</option>
            </select>
          </div>

          <Button onClick={handleSimulate}>Simulate Outcome</Button>

          {result && <p className="font-medium text-green-700">Outcome: {result}</p>}
        </CardContent>
      </Card>
    </div>
  );
}