import VeritasMagnaSimulator from './VeritasMagnaSimulator';

function App() {
  return <VeritasMagnaSimulator />;
}

export default App;